package afghan.hisab

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Entry(val id: Long, val title: String, val amount: Double, val type: String, val note: String, val date: String, val file: String = "")

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("afghan_hisab", Context.MODE_PRIVATE) }
    private val entries = mutableListOf<Entry>()
    private var language = "fa"
    private var search = ""
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private val green = Color.rgb(22, 105, 67)
    private val red = Color.rgb(180, 35, 45)
    private val black = Color.rgb(35, 35, 35)

    private fun t(fa: String, ps: String) = if (language == "fa") fa else ps

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        language = prefs.getString("lang", "fa") ?: "fa"
        loadEntries()
        if (prefs.getString("pin", null) != null) showLock() else showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 16f, color: Int = black, bold: Boolean = false): TextView =
        TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(dp(8), dp(7), dp(8), dp(7)) }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { action() }
    }
    private fun page(): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(248, 249, 247)); setPadding(dp(14), dp(12), dp(14), dp(8)) }
        setContentView(root); return root
    }
    private fun loadEntries() {
        entries.clear()
        val raw = prefs.getString("entries", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                entries.add(Entry(o.getLong("id"), o.getString("title"), o.getDouble("amount"), o.getString("type"), o.optString("note"), o.getString("date"), o.optString("file")))
            }
        } catch (_: Exception) {}
    }
    private fun saveEntries() {
        val arr = JSONArray()
        entries.forEach { e -> arr.put(JSONObject().put("id", e.id).put("title", e.title).put("amount", e.amount).put("type", e.type).put("note", e.note).put("date", e.date).put("file", e.file)) }
        prefs.edit().putString("entries", arr.toString()).apply()
    }
    private fun money(v: Double) = String.format(Locale.US, "%,.2f ؋", v)
    private fun showHome() {
        val p = page()
        val banner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(10), dp(16), dp(10), dp(16)); setBackgroundColor(green) }
        banner.addView(text("افغان حساب 🇦🇫", 25f, Color.WHITE, true))
        banner.addView(text(t("مدیریت ساده و امن حساب‌ها", "د حسابونو اسانه او خوندي سمبالښت"), 14f, Color.WHITE))
        p.addView(banner)
        val langRow = LinearLayout(this).apply { gravity = Gravity.END }
        langRow.addView(button(if (language == "fa") "پښتو" else "دری") {
            language = if (language == "fa") "ps" else "fa"; prefs.edit().putString("lang", language).apply(); showHome()
        })
        langRow.addView(button(t("امنیت", "امنیت")) { securityDialog() })
        p.addView(langRow)
        val income = entries.filter { it.type == "income" }.sumOf { it.amount }
        val expense = entries.filter { it.type == "expense" }.sumOf { it.amount }
        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(Color.WHITE) }
        summary.addView(text(t("مجموع درآمد", "ټول عاید"), 14f, green, true))
        summary.addView(text(money(income), 22f, green, true))
        summary.addView(text(t("مجموع مصارف", "ټول لګښتونه"), 14f, red, true))
        summary.addView(text(money(expense), 22f, red, true))
        summary.addView(text(t("باقی‌مانده", "پاتې پیسې"), 14f, black, true))
        summary.addView(text(money(income - expense), 24f, black, true))
        p.addView(summary)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(button(t("+ درآمد", "+ عاید")) { entryDialog("income", null) }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button(t("+ مصرف", "+ لګښت")) { entryDialog("expense", null) }, LinearLayout.LayoutParams(0, -2, 1f))
        p.addView(actions)
        val searchBox = EditText(this).apply { hint = t("جستجوی عنوان یا یادداشت", "د سرلیک یا یادښت لټون"); setSingleLine(true); setText(search) }
        searchBox.setOnEditorActionListener { v, _, _ -> search = v.text.toString(); renderList(); true }
        p.addView(searchBox)
        p.addView(text(t("فهرست حساب‌ها", "د حسابونو لړلیک"), 18f, black, true))
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list); p.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        renderList()
    }
    private fun renderList() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val filtered = entries.filter { it.title.contains(search, true) || it.note.contains(search, true) }.sortedByDescending { it.id }
        if (filtered.isEmpty()) list.addView(text(t("هنوز حسابی ثبت نشده است.", "تر اوسه حساب نه دی ثبت شوی."), 15f))
        filtered.forEach { e ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(Color.WHITE) }
            val color = if (e.type == "income") green else red
            card.addView(text("${e.title}  •  ${if (e.type == "income") t("درآمد", "عاید") else t("مصرف", "لګښت")}", 16f, color, true))
            card.addView(text(money(e.amount) + "     " + e.date, 14f))
            if (e.note.isNotBlank()) card.addView(text(e.note, 13f))
            if (e.file.isNotBlank()) card.addView(text(t("فایل ضمیمه شده", "فایل نښلول شوی"), 12f, green))
            val row = LinearLayout(this)
            row.addView(button(t("ویرایش", "سمون")) { entryDialog(e.type, e) }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button(t("حذف", "ړنګول")) {
                AlertDialog.Builder(this).setMessage(t("این مورد حذف شود؟", "دا توکی ړنګ شي؟"))
                    .setNegativeButton(t("خیر", "نه"), null).setPositiveButton(t("بلی", "هو")) { _, _ -> entries.removeAll { it.id == e.id }; saveEntries(); renderList(); refreshSummary() }.show()
            }, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(row); list.addView(card)
            val gap = View(this); gap.layoutParams = LinearLayout.LayoutParams(1, dp(8)); list.addView(gap)
        }
    }
    private fun refreshSummary() { showHome() }

    private var pendingFile: Uri? = null
    private fun entryDialog(type: String, old: Entry?) {
        pendingFile = old?.file?.let { runCatching { Uri.parse(it) }.getOrNull() }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        val title = EditText(this).apply { hint = t("عنوان", "سرلیک"); setText(old?.title ?: "") }
        val amount = EditText(this).apply { hint = t("مبلغ به افغانی", "مقدار په افغانیو"); inputType = 8194; setText(old?.amount?.toString() ?: "") }
        val note = EditText(this).apply { hint = t("یادداشت (اختیاری)", "یادښت (اختیاري)"); setText(old?.note ?: "") }
        box.addView(title); box.addView(amount); box.addView(note)
        box.addView(button(t("افزودن فایل", "فایل زیاتول")) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
            startActivityForResult(intent, 41)
        })
        AlertDialog.Builder(this).setTitle(if (type == "income") t("ثبت درآمد", "عاید ثبتول") else t("ثبت مصرف", "لګښت ثبتول"))
            .setView(box).setNegativeButton(t("انصراف", "لغوه")) { _, _ -> pendingFile = null }
            .setPositiveButton(t("ذخیره", "ساتل")) { _, _ ->
                val value = amount.text.toString().replace(",", "").toDoubleOrNull()
                if (title.text.isBlank() || value == null || value <= 0) {
                    Toast.makeText(this, t("عنوان و مبلغ معتبر وارد کنید.", "سم سرلیک او مقدار ولیکئ."), Toast.LENGTH_LONG).show()
                } else {
                    val date = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date())
                    val e = Entry(old?.id ?: System.currentTimeMillis(), title.text.toString(), value, type, note.text.toString(), if (old == null) date else old.date, pendingFile?.toString() ?: old?.file.orEmpty())
                    if (old != null) entries.removeAll { it.id == old.id }
                    entries.add(e); saveEntries(); pendingFile = null; showHome()
                }
            }.show()
    }
    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            pendingFile = data?.data
            pendingFile?.let { uri -> runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            Toast.makeText(this, t("فایل انتخاب شد؛ دوباره مورد را ذخیره کنید.", "فایل وټاکل شو؛ توکی بیا ثبت کړئ."), Toast.LENGTH_LONG).show()
        }
    }
    private fun securityDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(18), 0) }
        val pin = EditText(this).apply { hint = t("رمز ۴ رقمی", "۴ عددي کوډ"); inputType = 2; setText(prefs.getString("pin", "")) }
        val key = EditText(this).apply { hint = t("کلید بازیابی (حداقل ۸ حرف)", "د بېرته ترلاسه کولو کیلي (لږ تر لږه ۸ توري)"); setText(prefs.getString("recovery", "")) }
        box.addView(pin); box.addView(key)
        AlertDialog.Builder(this).setTitle(t("تنظیم امنیت", "د امنیت امستنې")).setView(box)
            .setNeutralButton(t("غیرفعال‌سازی قفل", "قلف بندول")) { _, _ -> prefs.edit().remove("pin").remove("recovery").apply(); Toast.makeText(this, t("قفل غیرفعال شد.", "قلف بند شو."), Toast.LENGTH_SHORT).show() }
            .setNegativeButton(t("انصراف", "لغوه"), null)
            .setPositiveButton(t("ذخیره", "ساتل")) { _, _ ->
                val p = pin.text.toString(); val k = key.text.toString()
                if (p.length == 4 && p.all { it.isDigit() } && k.length >= 8) {
                    prefs.edit().putString("pin", p).putString("recovery", k).apply()
                    Toast.makeText(this, t("قفل تنظیم شد.", "قلف تنظیم شو."), Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, t("رمز باید ۴ رقم و کلید حداقل ۸ حرف باشد.", "کوډ ۴ شمېرې او کیلي لږ تر لږه ۸ توري وي."), Toast.LENGTH_LONG).show()
            }.show()
    }
    private fun showLock() {
        val p = page()
        p.gravity = Gravity.CENTER
        p.addView(text("افغان حساب 🇦🇫", 26f, green, true))
        val pin = EditText(this).apply { hint = t("رمز چهاررقمی", "څلور عددي کوډ"); inputType = 2 }
        p.addView(pin)
        p.addView(button(t("ورود", "ننوتل")) {
            if (pin.text.toString() == prefs.getString("pin", null)) showHome()
            else Toast.makeText(this, t("رمز نادرست است.", "کوډ ناسم دی."), Toast.LENGTH_SHORT).show()
        })
        p.addView(button(t("بازیابی با کلید", "د کیلي له لارې بېرته ترلاسه کول")) {
            val key = EditText(this).apply { hint = t("کلید بازیابی", "د بېرته ترلاسه کولو کیلي") }
            AlertDialog.Builder(this).setTitle(t("بازیابی رمز", "د کوډ بېرته ترلاسه کول")).setView(key)
                .setPositiveButton(t("تأیید", "تایید")) { _, _ ->
                    if (key.text.toString() == prefs.getString("recovery", null)) showHome()
                    else Toast.makeText(this, t("کلید بازیابی نادرست است.", "د بېرته ترلاسه کولو کیلي ناسمه ده."), Toast.LENGTH_SHORT).show()
                }.setNegativeButton(t("انصراف", "لغوه"), null).show()
        })
    }
}
