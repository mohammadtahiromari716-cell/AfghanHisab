package af.tahir.afghanhisab

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class Entry(val id: Long, val title: String, val amount: Double, val income: Boolean, val date: String, val file: String = "")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AfghanHisabApp() }
    }
}

@Composable
fun AfghanHisabApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("afghan_hisab", Context.MODE_PRIVATE) }
    var language by remember { mutableStateOf(prefs.getString("lang", "fa") ?: "fa") }
    var pin by remember { mutableStateOf(prefs.getString("pin", "") ?: "") }
    var recovery by remember { mutableStateOf(prefs.getString("recovery", "") ?: "") }
    var lockEnabled by remember { mutableStateOf(prefs.getBoolean("lock", false)) }
    var unlocked by remember { mutableStateOf(!lockEnabled || pin.isBlank()) }
    var enteredPin by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Entry?>(null) }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var income by remember { mutableStateOf(true) }
    var attachment by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var entries by remember { mutableStateOf(loadEntries(prefs)) }
    var message by remember { mutableStateOf("") }

    fun save() {
        val arr = JSONArray()
        entries.forEach { e ->
            arr.put(JSONObject().put("id", e.id).put("title", e.title).put("amount", e.amount)
                .put("income", e.income).put("date", e.date).put("file", e.file))
        }
        prefs.edit().putString("entries", arr.toString()).apply()
    }
    fun tr(fa: String, ps: String) = if (language == "fa") fa else ps

    if (!unlocked) {
        LockScreen(
            title = tr("افغان حساب", "افغان حساب"),
            prompt = tr("رمز چهاررقمی را وارد کنید", "څلور عددي کوډ دننه کړئ"),
            value = enteredPin,
            onValue = { if (it.length <= 4) enteredPin = it },
            onUnlock = {
                if (enteredPin == pin) { unlocked = true; enteredPin = "" }
                else message = tr("رمز ناسم است", "کوډ ناسم دی")
            },
            onRecover = {
                message = tr("برای بازیابی، کلید بازیابی را وارد کنید", "د بېرته ترلاسه کولو کیلي دننه کړئ")
            },
            message = message
        )
        return
    }

    val totalIn = entries.filter { it.income }.sumOf { it.amount }
    val totalOut = entries.filter { !it.income }.sumOf { it.amount }
    val visible = entries.filter {
        it.title.contains(search, true) &&
        (filter == "all" || (filter == "in" && it.income) || (filter == "out" && !it.income))
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) attachment = uri.lastPathSegment ?: uri.toString()
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Color(0xFF176B45), secondary = Color(0xFFD7A928), background = Color(0xFFF6F7F5)
    )) {
        Box(Modifier.fillMaxSize().background(Color(0xFFF6F7F5))) {
            Column(Modifier.fillMaxSize()) {
                Box(
                    Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF111111), Color(0xFFB3262D), Color(0xFF16834A))))
                        .padding(20.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🇦🇫", style = MaterialTheme.typography.headlineMedium)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(tr("افغان حساب", "افغان حساب"), color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                Text(tr("مدیریت ساده و منظم پول", "د پیسو اسانه او منظم مدیریت"), color = Color.White.copy(alpha = .85f))
                            }
                            TextButton(onClick = { showSettings = true }) { Text(tr("تنظیمات", "امستنې"), color = Color.White) }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text(tr("باقی‌مانده", "پاتې پیسې"), color = Color.White.copy(alpha = .85f))
                        Text("${money(totalIn - totalOut)} ؋", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryCard(tr("درآمد", "عاید"), totalIn, Color(0xFF176B45), Modifier.weight(1f))
                    SummaryCard(tr("مصارف", "لګښت"), totalOut, Color(0xFFB3262D), Modifier.weight(1f))
                }
                OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    label = { Text(tr("جستجوی معاملات", "د معاملاتو لټون")) }, singleLine = true)
                Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(filter == "all", { filter = "all" }, label = { Text(tr("همه", "ټول")) })
                    FilterChip(filter == "in", { filter = "in" }, label = { Text(tr("درآمد", "عاید")) })
                    FilterChip(filter == "out", { filter = "out" }, label = { Text(tr("مصارف", "لګښت")) })
                }
                Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("معاملات", "معاملات"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    FilledTonalButton(onClick = { editing = null; title = ""; amount = ""; income = true; attachment = ""; showEditor = true }) {
                        Icon(Icons.Default.Add, null); Text(tr("ثبت معامله", "معامله ثبتول"))
                    }
                }
                if (visible.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text(tr("هنوز معامله‌ای ثبت نشده است.", "تر اوسه معامله نه ده ثبت شوې."))
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        items(visible, key = { it.id }) { e ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(16.dp)) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(e.title, fontWeight = FontWeight.SemiBold)
                                        Text(e.date, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        if (e.file.isNotBlank()) Text("📎 ${e.file}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text("${if (e.income) "+" else "-"}${money(e.amount)} ؋",
                                        color = if (e.income) Color(0xFF176B45) else Color(0xFFB3262D), fontWeight = FontWeight.Bold)
                                    IconButton(onClick = {
                                        editing = e; title = e.title; amount = e.amount.toString()
                                        income = e.income; attachment = e.file; showEditor = true
                                    }) { Icon(Icons.Default.Edit, tr("ویرایش", "سمون")) }
                                    IconButton(onClick = { entries = entries.filterNot { it.id == e.id }; save() }) {
                                        Icon(Icons.Default.Delete, tr("حذف", "ړنګول"), tint = Color(0xFFB3262D))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(tr("ثبت معامله", "معامله ثبتول")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text(tr("عنوان", "سرلیک")) }, singleLine = true)
                    OutlinedTextField(amount, { amount = it }, label = { Text(tr("مبلغ به افغانی", "اندازه په افغانۍ")) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(income, { income = true }, label = { Text(tr("درآمد", "عاید")) })
                        Spacer(Modifier.width(8.dp))
                        FilterChip(!income, { income = false }, label = { Text(tr("مصارف", "لګښت")) })
                    }
                    OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text(tr("افزودن فایل", "دوتنه زیاتول")) }
                    if (attachment.isNotBlank()) Text("📎 $attachment")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val a = amount.toDoubleOrNull()
                    if (title.isNotBlank() && a != null && a >= 0) {
                        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                        val item = Entry(editing?.id ?: Random.nextLong(), title.trim(), a, income,
                            editing?.date ?: stamp, attachment)
                        entries = if (editing == null) listOf(item) + entries else entries.map { if (it.id == item.id) item else it }
                        save(); showEditor = false
                    }
                }) { Text(tr("ذخیره", "ساتل")) }
            },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text(tr("لغو", "لغوه")) } }
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text(tr("تنظیمات", "امستنې")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(tr("زبان برنامه", "د اپلېکېشن ژبه"))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(language == "fa", { language = "fa"; prefs.edit().putString("lang", "fa").apply() }, label = { Text("دری") })
                        FilterChip(language == "ps", { language = "ps"; prefs.edit().putString("lang", "ps").apply() }, label = { Text("پښتو") })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("قفل چهاررقمی", "څلور عددي قلف"), Modifier.weight(1f))
                        Switch(lockEnabled, {
                            lockEnabled = it
                            prefs.edit().putBoolean("lock", it).apply()
                            if (!it) unlocked = true else if (pin.isNotBlank()) unlocked = false
                        })
                    }
                    var newPin by remember { mutableStateOf("") }
                    var recoveryInput by remember { mutableStateOf("") }
                    OutlinedTextField(newPin, { if (it.length <= 4) newPin = it }, label = { Text(tr("رمز جدید ۴ رقمی", "نوی ۴ عددي کوډ")) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedButton(onClick = {
                        if (newPin.length == 4 && newPin.all(Char::isDigit)) {
                            pin = newPin
                            recovery = "%04d-%04d".format(Random.nextInt(10000), Random.nextInt(10000))
                            prefs.edit().putString("pin", pin).putString("recovery", recovery).apply()
                            message = tr("کلید بازیابی جدید: $recovery — آن را یادداشت کنید", "د بیا ترلاسه کولو کیلي: $recovery — خوندي یې کړئ")
                            newPin = ""
                        }
                    }) { Text(tr("ثبت / تغییر رمز", "کوډ ثبت / بدلول")) }
                    Text(tr("کلید بازیابی", "د بېرته ترلاسه کولو کیلي"))
                    OutlinedTextField(recoveryInput, { recoveryInput = it }, label = { Text(tr("کلید بازیابی را وارد کنید", "د بیا ترلاسه کولو کیلي دننه کړئ")) }, singleLine = true)
                    OutlinedButton(onClick = {
                        if (recoveryInput == recovery && recovery.isNotBlank()) {
                            pin = ""; prefs.edit().remove("pin").apply()
                            message = tr("رمز حذف شد؛ اکنون رمز جدید تعیین کنید", "کوډ لرې شو؛ نوی کوډ وټاکئ")
                        } else message = tr("کلید بازیابی نادرست است", "د بیا ترلاسه کولو کیلي ناسمه ده")
                    }) { Text(tr("بازیابی رمز", "کوډ بېرته ترلاسه کول")) }
                    if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text(tr("بستن", "تړل")) } }
        )
    }
}

@Composable
fun SummaryCard(label: String, amount: Double, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Color.Gray)
            Text("${money(amount)} ؋", color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
fun LockScreen(title: String, prompt: String, value: String, onValue: (String) -> Unit,
               onUnlock: () -> Unit, onRecover: () -> Unit, message: String) {
    MaterialTheme {
        Column(Modifier.fillMaxSize().background(Color(0xFF176B45)).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("🇦🇫", style = MaterialTheme.typography.displayLarge)
            Text(title, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(value, onValue, label = { Text(prompt) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onUnlock) { Text("ورود") }
            TextButton(onClick = onRecover) { Text("بازیابی رمز", color = Color.White) }
            if (message.isNotBlank()) Text(message, color = Color.White)
        }
    }
}

fun money(v: Double): String = "%,.2f".format(Locale.US, v).removeSuffix(".00")
fun loadEntries(prefs: android.content.SharedPreferences): List<Entry> {
    return try {
        val arr = JSONArray(prefs.getString("entries", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Entry(o.getLong("id"), o.getString("title"), o.getDouble("amount"), o.getBoolean("income"),
                o.getString("date"), o.optString("file", ""))
        }
    } catch (_: Exception) { emptyList() }
}
