package com.tahir.hisab

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF101B35)
private val Gold = Color(0xFFD6A84F)
private val Pale = Color(0xFFF3F5FA)
private val Green = Color(0xFF16845B)
private val Red = Color(0xFFC74747)

data class Entry(val id: Long, val title: String, val amount: Long, val income: Boolean, val date: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TahirHisabApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TahirHisabApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tahir_hisab", Context.MODE_PRIVATE) }
    val entries = remember { mutableStateListOf<Entry>().apply { addAll(loadEntries(prefs)) } }
    var showAdd by remember { mutableStateOf(false) }
    var incomeMode by remember { mutableStateOf(true) }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }

    val incomeTotal = entries.filter { it.income }.sumOf { it.amount }
    val expenseTotal = entries.filter { !it.income }.sumOf { it.amount }
    val balance = incomeTotal - expenseTotal

    fun save() { prefs.edit().putString("entries", toJson(entries)).apply() }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Navy, secondary = Gold, background = Pale, surface = Color.White)
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("افغان حساب", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp)
                            Text("مدیریت سادهٔ دخل و خرج", color = Color(0xFFD9E0EF), fontSize = 12.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { title = ""; amount = ""; incomeMode = true; showAdd = true },
                    containerColor = Gold, contentColor = Navy) {
                    Icon(Icons.Default.Add, contentDescription = "افزودن")
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Navy)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccountBalanceWallet, null, tint = Gold)
                            Spacer(Modifier.width(8.dp))
                            Text("موجودی فعلی", color = Color.White, fontSize = 14.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("${balance} افغانی", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SummaryBox("درآمد", incomeTotal, Green, Modifier.weight(1f))
                            SummaryBox("مصرف", expenseTotal, Red, Modifier.weight(1f))
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                TabRow(selectedTabIndex = tab, containerColor = Color.White, contentColor = Navy) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("همه حساب‌ها") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("درآمد") })
                    Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("مصارف") })
                }
                Spacer(Modifier.height(10.dp))
                if (entries.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("هنوز حسابی ثبت نشده است.\nبرای شروع، دکمهٔ + را بزنید.", color = Color.Gray)
                    }
                } else {
                    val shown = entries.filter {
                        tab == 0 || (tab == 1 && it.income) || (tab == 2 && !it.income)
                    }.sortedByDescending { it.id }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(shown, key = { it.id }) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(16.dp)) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.title, fontWeight = FontWeight.SemiBold, color = Navy)
                                        Text(item.date, color = Color.Gray, fontSize = 12.sp)
                                    }
                                    Text("${if (item.income) "+" else "−"}${item.amount} افغانی",
                                        color = if (item.income) Green else Red, fontWeight = FontWeight.Bold)
                                    IconButton(onClick = { entries.remove(item); save() }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAdd) {
            AlertDialog(
                onDismissRequest = { showAdd = false },
                title = { Text("ثبت حساب جدید") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = incomeMode, onClick = { incomeMode = true }, label = { Text("درآمد") })
                            FilterChip(selected = !incomeMode, onClick = { incomeMode = false }, label = { Text("مصرف") })
                        }
                        OutlinedTextField(value = title, onValueChange = { title = it },
                            label = { Text("عنوان (مثلاً فروش یا کرایه)") }, singleLine = true)
                        OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) },
                            label = { Text("مبلغ به افغانی") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val value = amount.toLongOrNull()
                        if (title.isNotBlank() && value != null && value > 0) {
                            val date = SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.getDefault()).format(Date())
                            entries.add(Entry(System.currentTimeMillis(), title.trim(), value, incomeMode, date))
                            save()
                            showAdd = false
                        }
                    }) { Text("ثبت") }
                },
                dismissButton = { TextButton(onClick = { showAdd = false }) { Text("لغو") } }
            )
        }
    }
}

@Composable
fun SummaryBox(label: String, value: Long, color: Color, modifier: Modifier = Modifier) {
    Column(modifier.background(Color(0xFF202D49), RoundedCornerShape(14.dp)).padding(12.dp)) {
        Text(label, color = Color(0xFFD9E0EF), fontSize = 12.sp)
        Text("$value", color = color, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text("افغانی", color = Color(0xFFD9E0EF), fontSize = 10.sp)
    }
}

fun loadEntries(prefs: android.content.SharedPreferences): List<Entry> {
    return try {
        val arr = JSONArray(prefs.getString("entries", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Entry(o.getLong("id"), o.getString("title"), o.getLong("amount"), o.getBoolean("income"), o.getString("date"))
        }
    } catch (_: Exception) { emptyList() }
}

fun toJson(entries: List<Entry>): String {
    val arr = JSONArray()
    entries.forEach {
        arr.put(JSONObject().put("id", it.id).put("title", it.title).put("amount", it.amount)
            .put("income", it.income).put("date", it.date))
    }
    return arr.toString()
}
